package com.cv_builder.cv_builder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CvBuilderApplicationTests {

	@Test
	void contextLoads() {
	}

}
