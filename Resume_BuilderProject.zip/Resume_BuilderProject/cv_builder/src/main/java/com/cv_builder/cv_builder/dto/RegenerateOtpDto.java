package com.cv_builder.cv_builder.dto;

public class RegenerateOtpDto {
    private String email;

    // Getters and setters
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
