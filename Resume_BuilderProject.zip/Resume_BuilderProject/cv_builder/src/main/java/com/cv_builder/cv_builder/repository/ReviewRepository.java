package com.cv_builder.cv_builder.repository;

import com.cv_builder.cv_builder.entity.Review;

import org.springframework.data.jpa.repository.JpaRepository;


public interface ReviewRepository extends JpaRepository<Review, Long> {

}
