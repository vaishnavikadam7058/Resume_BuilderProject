package com.cv_builder.cv_builder.service;

import com.cv_builder.cv_builder.dto.ProfileDTO;
import com.cv_builder.cv_builder.model.Profile;
import com.cv_builder.cv_builder.repository.ProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ProfileService {

    @Autowired
    private ProfileRepository profileRepository;

    public ProfileDTO createProfile(ProfileDTO profileDTO) {
        Profile profile = new Profile();
        profile.setFirstName(profileDTO.getFirstName());
        profile.setLastName(profileDTO.getLastName());
        profile.setEmail(profileDTO.getEmail());
        profile.setPhoneNumber(profileDTO.getPhoneNumber());
        profile.setAddress(profileDTO.getAddress());
        profileRepository.save(profile);

        return profileDTO;
    }

    public ProfileDTO getProfile(Long id) {
        Optional<Profile> profile = profileRepository.findById(id);
        if (profile.isPresent()) {
            Profile p = profile.get();
            ProfileDTO profileDTO = new ProfileDTO();
            profileDTO.setFirstName(p.getFirstName());
            profileDTO.setLastName(p.getLastName());
            profileDTO.setEmail(p.getEmail());
            profileDTO.setPhoneNumber(p.getPhoneNumber());
            profileDTO.setAddress(p.getAddress());
            return profileDTO;
        }
        return null;
    }

    public List<ProfileDTO> getAllProfiles() {
        return profileRepository.findAll().stream().map(profile -> {
            ProfileDTO profileDTO = new ProfileDTO();
            profileDTO.setFirstName(profile.getFirstName());
            profileDTO.setLastName(profile.getLastName());
            profileDTO.setEmail(profile.getEmail());
            profileDTO.setPhoneNumber(profile.getPhoneNumber());
            profileDTO.setAddress(profile.getAddress());
            return profileDTO;
        }).collect(Collectors.toList());
    }

    public ProfileDTO updateProfile(Long id, ProfileDTO profileDTO) {
        Optional<Profile> optionalProfile = profileRepository.findById(id);
        if (optionalProfile.isPresent()) {
            Profile profile = optionalProfile.get();
            profile.setFirstName(profileDTO.getFirstName());
            profile.setLastName(profileDTO.getLastName());
            profile.setEmail(profileDTO.getEmail());
            profile.setPhoneNumber(profileDTO.getPhoneNumber());
            profile.setAddress(profileDTO.getAddress());
            profileRepository.save(profile);
            return profileDTO;
        }
        return null;
    }

    public void deleteProfile(Long id) {
        profileRepository.deleteById(id);
    }
}

