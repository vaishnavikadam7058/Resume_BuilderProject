package com.cv_builder.cv_builder.repository;

public class ProfileRepository {

}
