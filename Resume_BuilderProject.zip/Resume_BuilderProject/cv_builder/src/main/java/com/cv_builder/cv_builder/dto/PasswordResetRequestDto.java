package com.cv_builder.cv_builder.dto;

import lombok.Data;

@Data
public class PasswordResetRequestDto {
    private String email;
}